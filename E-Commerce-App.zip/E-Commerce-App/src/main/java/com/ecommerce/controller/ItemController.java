package com.ecommerce.controller;

import com.ecommerce.entity.Item;
import com.ecommerce.exception.ResourceNotFoundException;
import com.ecommerce.service.ItemService;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/items")
public class ItemController {
	@Autowired
	private ItemService itemService;

	@GetMapping
	public List<Item> getAllItems() {
		return itemService.findAll();
	}

	@GetMapping("/{itemId}")
	public ResponseEntity<Item> getItemById(@PathVariable Long itemId) {
		return itemService.findById(itemId).map(ResponseEntity::ok)
				.orElseThrow(() -> new ResourceNotFoundException("Item not found with id " + itemId));
	}

	@PostMapping
	public Item createItem(@Validated @RequestBody Item item) {
		return itemService.save(item);
	}

	@PutMapping("/{itemId}")
	public ResponseEntity<Item> updateItem(@PathVariable Long itemId, @Validated @RequestBody Item itemDetails) {
		return itemService.findById(itemId).map(item -> {
			item.setName(itemDetails.getName());
			item.setPrice(itemDetails.getPrice());
			item.setDescription(itemDetails.getDescription());
			item.setCategory(itemDetails.getCategory());
			return ResponseEntity.ok(itemService.save(item));
		}).orElseThrow(() -> new ResourceNotFoundException("Item not found with id " + itemId));
	}

	@DeleteMapping("/{itemId}")
	public ResponseEntity<Object> deleteItem(@PathVariable Long itemId) {
		return itemService.findById(itemId).map(item -> {
			itemService.deleteById(itemId);
			return ResponseEntity.ok().build();
		}).orElseThrow(() -> new ResourceNotFoundException("Item not found with id " + itemId));
	}
}