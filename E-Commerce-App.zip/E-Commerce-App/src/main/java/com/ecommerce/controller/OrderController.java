package com.ecommerce.controller;

import com.ecommerce.entity.Order;
import com.ecommerce.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/orders")
public class OrderController {
	@Autowired
	private OrderService orderService;

	@GetMapping
	public List<Order> getAllOrders() {
		return orderService.findAll();
	}

	@GetMapping("/{orderId}")
	public ResponseEntity<Order> getOrderById(@PathVariable Long orderId) {
		return orderService.findById(orderId).map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());
	}

	@PostMapping
	public Order createOrder(@RequestBody Order order) {
		return orderService.save(order);
	}

	@PutMapping("/{orderId}")
	public ResponseEntity<Order> updateOrder(@PathVariable Long orderId, @RequestBody Order orderDetails) {
		return orderService.findById(orderId).map(order -> {
			order.setUserId(orderDetails.getUserId());
			order.setOrderDate(orderDetails.getOrderDate());
			order.setTotalAmount(orderDetails.getTotalAmount());
			order.setItems(orderDetails.getItems());
			return ResponseEntity.ok(orderService.save(order));
		}).orElse(ResponseEntity.notFound().build());
	}

	@DeleteMapping("/{orderId}")
	public ResponseEntity<Object> deleteOrder(@PathVariable Long orderId) {
		return orderService.findById(orderId).map(order -> {
			orderService.deleteById(orderId);
			return ResponseEntity.ok().build();
		}).orElse(ResponseEntity.notFound().build());
	}
}